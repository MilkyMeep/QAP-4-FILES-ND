// Desc:
// Author:
// Dates:

var $ = function (id) {
  return document.getElementById(id);
};  


// Define format options for printing.
const cur2Format = new Intl.NumberFormat("en-CA", {
  style: "currency",
  currency: "CAD",
  minimumFractionDigits: "2",
  maximumFractionDigits: "2",
});

const per2Format = new Intl.NumberFormat("en-CA", {
  style: "percent",
  minimumFractionDigits: "2",
  maximumFractionDigits: "2",
});

const com2Format = new Intl.NumberFormat("en-CA", {
  style: "decimal",
  minimumFractionDigits: "2",
  maximumFractionDigits: "2",
});


// Define program constants.
let EvenSite = 80
let OddSite = 120
let AltMemCost = 5
let WeekCleanCost = 50
let VidSurvCost = 35
let StandardCost = 75
let ExecCost = 150




// Start main program here.
let EvenArr = new Array("2", "4", "6", "8", "10","12", "14", "16", "18", "20","22", "24", "26", "28", "30","32", "34", "36", "38", "40","42", "44", "46", "48", "50","52", "54", "56", "58", "60", "62", "64", "66", "68", "70" ,"72", "74", "76", "78", "80","82", "84", "86", "88", "90","92", "94", "96", "98", "100");
let OddArr = new Array("1", "3", "5", "7", "9","11", "13", "15", "17", "19","21", "23", "25", "27", "29","31", "33","35", "37", "39","41", "43", "45", "47", "49","51", "53", "55", "57", "59","61", "63", "65", "67", "69","71", "73", "75", "77", "79","81", "83", "85", "87", "89","91", "93", "95", "97", "99");

let Date = prompt("Enter The Date XXXX-XX-XX:              ")

let SiteNum = prompt("Enter The Site Number 1-100:         ")

let Name = prompt("Enter The Member Name:                  ")

let StrAddy = prompt("Enter Their Street Address:          ")

let City = prompt("Enter The Members City:                 ")

let Prov = prompt("Enter The Members Province:             ")

let Postal = prompt("Enter The Members Postal Code:        ")

let PhoneNum = prompt("Enter The Members Phone Number:     ")

let CellNum = prompt("Enter The Members Cell Number:       ")

let MemType = prompt("Enter The Membership Type S/E:       ")

let AltMem = prompt("Enter The Number Of Altenate Members: ")

let WeekClean =prompt("Recieving Weekly Cleaning Y/N:      ").toUpperCase()

let VidSurv = prompt("Recieving Video Surveliance Y/N:     ").toUpperCase()

// Calculations
if (EvenArr == SiteNum)
  SiteCha = EvenSite
else
SiteCha = OddSite


AltMemCalc = AltMem * AltMemCost

SiteCharge = AltMemCalc + SiteCha 

if (WeekClean =="Y")
  WeekCleanCalc = WeekCleanCost
else WeekCleanCalc = 0

if (VidSurv =="Y")
  VidSurvCalc = VidSurvCost
else VidSurvCalc = 0
ExCharge = VidSurvCalc + WeekCleanCalc




if (MemType == "S")
  MemCostCalc = StandardCost
else MemCostCalc = ExecCost

let Subtotal = SiteCharge + ExCharge
let HST = Subtotal * .15
let TotMonCha = Subtotal + HST
let TotMonFee = TotMonCha + MemCostCalc
let TotYearFee = TotMonFee * 12
let MonthlyPayment = (TotYearFee + 59.99) / 12 
let CancelFee =  TotYearFee * .60

/* Display
print ("St John's Marina & Yacht Club Yearly Member Recipt ")
print (" --------------------------------------------------")
print ("Client Name And Address:                           ")
print ("---------------------------------------------------")
print (f(Name,             
                                                    StrAddy ))
print ()
print("Phone:", PhoneNum ,"(H)                             ")
print("      ", CellNum  ,"(C)                             ")
print("----------------------------------------------------")
print ("Site #:", SiteNum, "Membership Type:", MemType      )
print("----------------------------------------------------")
print("Alternate Members",                           AltMem )
print("Weekly Site Cleaning",             WeekClean         )
print("Video Survelaince",                VidSurv           )
print("----------------------------------------------------")
print("Site Charges",                    SiteCharge,        )
print("Video Survelaince",                VidSurv           ) */


document.getElementById("Name").innerText = Name;

document.getElementById("Address").innerText = StrAddy;

document.getElementById("PhoneNum").innerText = PhoneNum;

document.getElementById("CellNum").innerText = CellNum;

document.getElementById("SiteNum").innerText = SiteNum;

document.getElementById("MemType").innerText = MemType;

document.getElementById("AltMem").innerText = AltMem;

document.getElementById("WeekClean").innerText = WeekClean;

document.getElementById("VidSurv").innerText = VidSurv;

document.getElementById("SiteCharge").innerText = "$" + SiteCharge.toFixed(2);

document.getElementById("ExCharge").innerText = "$" + ExCharge.toFixed(2);

document.getElementById("SubTot").innerText = "$" + Subtotal.toFixed(2);

document.getElementById("HST").innerText = "$" + HST.toFixed(2);

document.getElementById("TotMonCha").innerText = "$" + TotMonCha.toFixed(2);

document.getElementById("SiteCha").innerText = "$" + SiteCha.toFixed(2);

document.getElementById("TotMonFee").innerText = "$" + TotMonFee.toFixed(2);

document.getElementById("TotYearFee").innerText = "$" + TotYearFee.toFixed(2);

document.getElementById("MonthlyPayment").innerText = "$" + MonthlyPayment.toFixed(2);

document.getElementById("Date").innerText = Date;

document.getElementById("subtotal").innerText = "$" + subtotal.toFixed(2);

document.getElementById("CancelFee").innerText = "$" + CancelFee.toFixed(2);